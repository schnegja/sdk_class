# Pause AWS resources to minimize cost.
# Scales the ECS service to 0 tasks (stops Fargate compute charges).
# Leaves ALB, CloudFront, ECR image, IAM, secrets in place so resume is fast
# and the Azure Bot endpoint URL does not change.
#
# Approximate idle cost after pause (us-east-2):
#   ALB:        ~$16/month (always-on, cannot be stopped without deleting)
#   CloudFront: ~$0 idle (pay per request)
#   ECR image:  ~$0.10/GB/month
#   Secrets:    ~$0.40/secret/month (2 secrets => ~$0.80)
#   ECS task:   $0 while desired-count = 0
#
# Usage:
#   .\pause-aws.ps1
#   .\pause-aws.ps1 -DisableCloudFront   # also disable CF distribution

[CmdletBinding()]
param(
  [string]$Region          = 'us-east-2',
  [string]$Cluster         = 'openai-basic',
  [string]$Service         = 'openai-basic-svc',
  [string]$DistributionId  = 'E32Y1ORPYFSR72',
  [switch]$DisableCloudFront
)

$ErrorActionPreference = 'Stop'

Write-Host "[pause] Scaling ECS service '$Service' to 0..." -ForegroundColor Cyan
aws ecs update-service `
  --cluster $Cluster `
  --service $Service `
  --desired-count 0 `
  --region $Region `
  --query 'service.{Service:serviceName,Desired:desiredCount,Running:runningCount}' `
  --output json | Write-Host

if ($DisableCloudFront) {
  Write-Host "[pause] Disabling CloudFront distribution '$DistributionId'..." -ForegroundColor Cyan
  $tmp = New-TemporaryFile
  aws cloudfront get-distribution-config --id $DistributionId --output json > $tmp
  $payload = Get-Content $tmp -Raw | ConvertFrom-Json
  $etag    = $payload.ETag
  $cfg     = $payload.DistributionConfig
  $cfg.Enabled = $false
  ($cfg | ConvertTo-Json -Depth 50) | Set-Content -Encoding utf8 $tmp
  aws cloudfront update-distribution --id $DistributionId --if-match $etag --distribution-config "file://$tmp" --query 'Distribution.{Id:Id,Status:Status,Enabled:DistributionConfig.Enabled}' --output json | Write-Host
  Remove-Item $tmp -Force
}

Write-Host "`n[pause] Done. To resume: .\resume-aws.ps1" -ForegroundColor Green
Write-Host "Note: ALB still incurs ~`$16/month. Run cleanup-aws.ps1 to delete everything." -ForegroundColor Yellow
