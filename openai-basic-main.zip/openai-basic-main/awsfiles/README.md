# AWS deployment files

This folder contains everything needed to deploy `OpenAI-basic` to **AWS ECS Fargate** behind a **CloudFront → ALB** front door, then point an **Azure Bot Service** resource at it for Web Chat / Teams / Direct Line testing.

| File | Purpose |
|---|---|
| `task-def.template.json` | ECS Fargate task definition (placeholders are replaced by `deploy-aws.ps1`) |
| `deploy-aws.ps1` | Idempotent end-to-end deploy script (run after `aws configure`) |
| `aws-resources.json` | Auto-generated record of every ARN/ID created (do NOT commit secrets) |
| `cleanup-aws.ps1` | Tears everything down in the correct order |

## Architecture

```
Browser → Azure Bot Service (Web Chat) → CloudFront (HTTPS) → ALB (HTTP, internal)
       → ECS Fargate task (container :3978) → OpenAI API
```

CloudFront gives a free `*.cloudfront.net` HTTPS URL so we don't need to own a domain or request an ACM cert in `us-east-1`.

## Resources created

- ECR repository `openai-basic`
- Secrets Manager: `openai-basic/openai-key`, `openai-basic/bot-client-secret`
- IAM roles: `openai-basic-exec-role`, `openai-basic-task-role`
- CloudWatch log group `/ecs/openai-basic`
- ECS cluster `openai-basic`, service `openai-basic-svc`, task family `openai-basic`
- ALB `openai-basic-alb` (HTTP :80, internal-friendly), target group `openai-basic-tg`
- 2 security groups: `openai-basic-alb-sg`, `openai-basic-task-sg`
- CloudFront distribution (origin = ALB, protocol = HTTP-only origin, viewer = HTTPS)
- Azure: Entra app `openai-basic-bot`, Azure Bot resource `openai-basic-bot`

## Region

`us-east-2` (Ohio).
