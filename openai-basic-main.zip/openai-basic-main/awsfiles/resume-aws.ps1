# Resume AWS resources after pause-aws.ps1.
# Scales the ECS service back to 1 task and (optionally) re-enables CloudFront.
#
# Usage:
#   .\resume-aws.ps1
#   .\resume-aws.ps1 -EnableCloudFront    # also re-enable CF distribution
#   .\resume-aws.ps1 -DesiredCount 2      # scale to N tasks

[CmdletBinding()]
param(
  [string]$Region          = 'us-east-2',
  [string]$Cluster         = 'openai-basic',
  [string]$Service         = 'openai-basic-svc',
  [string]$DistributionId  = 'E32Y1ORPYFSR72',
  [int]   $DesiredCount    = 1,
  [switch]$EnableCloudFront
)

$ErrorActionPreference = 'Stop'

if ($EnableCloudFront) {
  Write-Host "[resume] Enabling CloudFront distribution '$DistributionId'..." -ForegroundColor Cyan
  $tmp = New-TemporaryFile
  aws cloudfront get-distribution-config --id $DistributionId --output json > $tmp
  $payload = Get-Content $tmp -Raw | ConvertFrom-Json
  $etag    = $payload.ETag
  $cfg     = $payload.DistributionConfig
  $cfg.Enabled = $true
  ($cfg | ConvertTo-Json -Depth 50) | Set-Content -Encoding utf8 $tmp
  aws cloudfront update-distribution --id $DistributionId --if-match $etag --distribution-config "file://$tmp" --query 'Distribution.{Id:Id,Status:Status,Enabled:DistributionConfig.Enabled}' --output json | Write-Host
  Remove-Item $tmp -Force
}

Write-Host "[resume] Scaling ECS service '$Service' to $DesiredCount..." -ForegroundColor Cyan
aws ecs update-service `
  --cluster $Cluster `
  --service $Service `
  --desired-count $DesiredCount `
  --region $Region `
  --query 'service.{Service:serviceName,Desired:desiredCount,Running:runningCount}' `
  --output json | Write-Host

Write-Host "[resume] Waiting for tasks to become healthy..." -ForegroundColor Cyan
$tgArn = 'arn:aws:elasticloadbalancing:us-east-2:903219762962:targetgroup/openai-basic-tg/63d03e7f321622d7'
for ($i = 0; $i -lt 40; $i++) {
  $states = aws elbv2 describe-target-health --target-group-arn $tgArn --region $Region --query 'TargetHealthDescriptions[].TargetHealth.State' --output text
  Write-Host "  [$i] $states"
  $tokens = $states -split '\s+' | Where-Object { $_ }
  if ($tokens.Count -gt 0 `
      -and ($tokens -contains 'healthy') `
      -and -not ($tokens -contains 'initial') `
      -and -not ($tokens -contains 'unhealthy') `
      -and -not ($tokens -contains 'draining')) {
    Write-Host "[resume] Healthy." -ForegroundColor Green
    break
  }
  Start-Sleep -Seconds 15
}

Write-Host "`n[resume] Bot endpoint: https://d25ae0qw3uh3eu.cloudfront.net/api/messages" -ForegroundColor Green
