# Rebuild + push the container image and roll the ECS Fargate service.
# Use this after editing src/*.py (or anything else baked into the image).
#
# What it does:
#   1. Picks the next image tag (or uses -Tag).
#   2. docker build + docker push to ECR.
#   3. Updates awsfiles/task-def.json image line.
#   4. Registers a new task definition revision.
#   5. Updates the ECS service to the new revision (force-new-deployment).
#   6. Waits for the service to stabilize.
#
# Env vars / secrets are NOT changed. To update those, edit task-def.json
# (or update the secret in Secrets Manager) and re-run with -SkipBuild.
#
# Usage:
#   .\redeploy-aws.ps1                  # auto-bump tag (v1 -> v2 -> v3 ...)
#   .\redeploy-aws.ps1 -Tag v5          # use explicit tag
#   .\redeploy-aws.ps1 -SkipBuild       # only register TD + roll service
#   .\redeploy-aws.ps1 -SkipWait        # don't wait for services-stable

[CmdletBinding()]
param(
  [string]$Region    = 'us-east-2',
  [string]$Account   = '903219762962',
  [string]$Repo      = 'openai-basic',
  [string]$Cluster   = 'openai-basic',
  [string]$Service   = 'openai-basic-svc',
  [string]$Family    = 'openai-basic',
  [string]$ProjectRoot = (Resolve-Path "$PSScriptRoot\.."),
  [string]$TaskDefFile = (Join-Path (Resolve-Path "$PSScriptRoot") 'task-def.json'),
  [string]$Tag,
  [switch]$SkipBuild,
  [switch]$SkipWait
)

$ErrorActionPreference = 'Stop'
$RegistryHost = "$Account.dkr.ecr.$Region.amazonaws.com"

# --- Pick next tag if not supplied ---
if (-not $Tag) {
  Write-Host "[redeploy] Discovering next image tag..." -ForegroundColor Cyan
  $existing = aws ecr list-images --repository-name $Repo --region $Region `
    --query 'imageIds[].imageTag' --output text 2>$null
  $maxN = 0
  if ($existing) {
    foreach ($t in ($existing -split '\s+')) {
      if ($t -match '^v(\d+)$') {
        $n = [int]$Matches[1]
        if ($n -gt $maxN) { $maxN = $n }
      }
    }
  }
  $Tag = "v$($maxN + 1)"
}
$ImageUri = "$RegistryHost/$Repo`:$Tag"
Write-Host "[redeploy] Target image: $ImageUri" -ForegroundColor Green

# --- Build + push ---
if (-not $SkipBuild) {
  Write-Host "[redeploy] Logging in to ECR..." -ForegroundColor Cyan
  $pw = aws ecr get-login-password --region $Region
  $pw | docker login --username AWS --password-stdin $RegistryHost | Out-Null

  Write-Host "[redeploy] docker build $ProjectRoot ..." -ForegroundColor Cyan
  docker build -t $ImageUri $ProjectRoot
  if ($LASTEXITCODE -ne 0) { throw "docker build failed" }

  Write-Host "[redeploy] docker push $ImageUri ..." -ForegroundColor Cyan
  docker push $ImageUri
  if ($LASTEXITCODE -ne 0) { throw "docker push failed" }
}
else {
  Write-Host "[redeploy] -SkipBuild set; using existing $ImageUri" -ForegroundColor Yellow
}

# --- Patch task-def.json image line ---
Write-Host "[redeploy] Updating $TaskDefFile image -> $ImageUri" -ForegroundColor Cyan
$td = Get-Content -Raw -Path $TaskDefFile | ConvertFrom-Json
$td.containerDefinitions[0].image = $ImageUri
($td | ConvertTo-Json -Depth 50) | Set-Content -Encoding utf8 -Path $TaskDefFile

# --- Register new revision ---
Write-Host "[redeploy] Registering new task definition revision..." -ForegroundColor Cyan
$tdArn = aws ecs register-task-definition --cli-input-json "file://$TaskDefFile" `
  --region $Region --query 'taskDefinition.taskDefinitionArn' --output text
Write-Host "[redeploy] Registered: $tdArn" -ForegroundColor Green

# --- Roll the service ---
Write-Host "[redeploy] Updating ECS service to new revision..." -ForegroundColor Cyan
aws ecs update-service --cluster $Cluster --service $Service `
  --task-definition $tdArn --force-new-deployment --region $Region `
  --query 'service.{Service:serviceName,TaskDef:taskDefinition,Desired:desiredCount}' `
  --output json | Write-Host

if ($SkipWait) {
  Write-Host "`n[redeploy] -SkipWait set; deployment is in flight." -ForegroundColor Yellow
  return
}

Write-Host "[redeploy] Waiting for service to stabilize (this can take 2-5 min)..." -ForegroundColor Cyan
aws ecs wait services-stable --cluster $Cluster --services $Service --region $Region

Write-Host "`n[redeploy] Done. Smoke test:" -ForegroundColor Green
try {
  $code = (Invoke-WebRequest 'https://d25ae0qw3uh3eu.cloudfront.net/api/messages' -UseBasicParsing -TimeoutSec 15).StatusCode
} catch { $code = $_.Exception.Response.StatusCode.value__ }
Write-Host "  https://d25ae0qw3uh3eu.cloudfront.net/api/messages -> HTTP $code  (expect 401)" -ForegroundColor Green
