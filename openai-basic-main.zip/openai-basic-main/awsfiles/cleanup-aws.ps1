# Cleanly delete ALL AWS resources for openai-basic.
# Use this for full teardown (no idle costs, but resume requires re-deploy).
#
# Order matters: CloudFront -> ECS service -> cluster -> ALB/listener/TG ->
#   security groups -> IAM role policies/roles -> secrets -> log group ->
#   ECR repo (with images).
# Skips Entra app and Azure Bot (delete those manually if desired).
#
# Usage:
#   .\cleanup-aws.ps1                     # prompts before each destructive step
#   .\cleanup-aws.ps1 -Force              # no prompts
#   .\cleanup-aws.ps1 -SkipCloudFront     # leave CF (it takes 15-20 min to disable+delete)

[CmdletBinding()]
param(
  [string]$Region                = 'us-east-2',
  [string]$Cluster               = 'openai-basic',
  [string]$Service               = 'openai-basic-svc',
  [string]$DistributionId        = 'E32Y1ORPYFSR72',
  [string]$AlbArn                = 'arn:aws:elasticloadbalancing:us-east-2:903219762962:loadbalancer/app/openai-basic-alb/2ecd6ffe2f6e7bff',
  [string]$ListenerArn           = 'arn:aws:elasticloadbalancing:us-east-2:903219762962:listener/app/openai-basic-alb/2ecd6ffe2f6e7bff/f507f5a9da787112',
  [string]$TargetGroupArn        = 'arn:aws:elasticloadbalancing:us-east-2:903219762962:targetgroup/openai-basic-tg/63d03e7f321622d7',
  [string]$AlbSg                 = 'sg-0f0cdfcfb9b20a2c7',
  [string]$TaskSg                = 'sg-069e6613f11684037',
  [string]$ExecRole              = 'openai-basic-exec-role',
  [string]$TaskRole              = 'openai-basic-task-role',
  [string]$OpenAiSecretArn       = 'arn:aws:secretsmanager:us-east-2:903219762962:secret:openai-basic/openai-key-xVxflP',
  [string]$BotSecretArn          = 'arn:aws:secretsmanager:us-east-2:903219762962:secret:openai-basic/bot-client-secret-uOIy7Z',
  [string]$LogGroup              = '/ecs/openai-basic',
  [string]$EcrRepo               = 'openai-basic',
  [switch]$SkipCloudFront,
  [switch]$Force
)

$ErrorActionPreference = 'Continue'

function Confirm-Step([string]$msg) {
  if ($Force) { return $true }
  $r = Read-Host "$msg  [y/N]"
  return ($r -eq 'y' -or $r -eq 'Y')
}

# --- 1. CloudFront: disable then delete (slow) ---
if (-not $SkipCloudFront) {
  if (Confirm-Step "Disable + delete CloudFront distribution $DistributionId? (15-20 min)") {
    Write-Host "[cleanup] Disabling CloudFront..." -ForegroundColor Cyan
    $tmp = New-TemporaryFile
    aws cloudfront get-distribution-config --id $DistributionId --output json > $tmp
    $payload = Get-Content $tmp -Raw | ConvertFrom-Json
    $etag    = $payload.ETag
    $cfg     = $payload.DistributionConfig
    if ($cfg.Enabled) {
      $cfg.Enabled = $false
      ($cfg | ConvertTo-Json -Depth 50) | Set-Content -Encoding utf8 $tmp
      aws cloudfront update-distribution --id $DistributionId --if-match $etag --distribution-config "file://$tmp" --output json > $null
    }
    Remove-Item $tmp -Force

    Write-Host "[cleanup] Waiting for CloudFront Deployed (post-disable)..." -ForegroundColor Cyan
    for ($i=0; $i -lt 90; $i++) {
      $s = aws cloudfront get-distribution --id $DistributionId --query 'Distribution.Status' --output text
      Write-Host "  [$i] $s"
      if ($s -eq 'Deployed') { break }
      Start-Sleep 20
    }
    $etag2 = aws cloudfront get-distribution --id $DistributionId --query 'ETag' --output text
    aws cloudfront delete-distribution --id $DistributionId --if-match $etag2
  }
}

# --- 2. ECS service + cluster ---
if (Confirm-Step "Delete ECS service $Service and cluster $Cluster?") {
  Write-Host "[cleanup] Scaling ECS service to 0..." -ForegroundColor Cyan
  aws ecs update-service --cluster $Cluster --service $Service --desired-count 0 --region $Region --output text > $null
  Write-Host "[cleanup] Waiting for tasks to drain..." -ForegroundColor Cyan
  aws ecs wait services-stable --cluster $Cluster --services $Service --region $Region
  aws ecs delete-service --cluster $Cluster --service $Service --region $Region --output text > $null
  aws ecs delete-cluster --cluster $Cluster --region $Region --output text > $null
}

# --- 3. ALB / Listener / Target Group ---
if (Confirm-Step "Delete ALB, listener, target group?") {
  Write-Host "[cleanup] Deleting listener..." -ForegroundColor Cyan
  aws elbv2 delete-listener --listener-arn $ListenerArn --region $Region
  Write-Host "[cleanup] Deleting load balancer..." -ForegroundColor Cyan
  aws elbv2 delete-load-balancer --load-balancer-arn $AlbArn --region $Region
  Start-Sleep 30
  Write-Host "[cleanup] Deleting target group..." -ForegroundColor Cyan
  aws elbv2 delete-target-group --target-group-arn $TargetGroupArn --region $Region
}

# --- 4. Security groups ---
if (Confirm-Step "Delete security groups $TaskSg and $AlbSg?") {
  aws ec2 delete-security-group --group-id $TaskSg --region $Region
  Start-Sleep 5
  aws ec2 delete-security-group --group-id $AlbSg  --region $Region
}

# --- 5. IAM roles ---
if (Confirm-Step "Detach + delete IAM roles $ExecRole, $TaskRole?") {
  # Exec role: detach managed, delete inline, delete role
  aws iam detach-role-policy --role-name $ExecRole --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy 2>$null
  aws iam delete-role-policy --role-name $ExecRole --policy-name read-secrets 2>$null
  aws iam delete-role --role-name $ExecRole
  aws iam delete-role --role-name $TaskRole
}

# --- 6. Secrets Manager (force delete, no recovery window) ---
if (Confirm-Step "Force-delete Secrets Manager entries (no recovery)?") {
  aws secretsmanager delete-secret --secret-id $OpenAiSecretArn --force-delete-without-recovery --region $Region --output text > $null
  aws secretsmanager delete-secret --secret-id $BotSecretArn   --force-delete-without-recovery --region $Region --output text > $null
}

# --- 7. CloudWatch Log group ---
if (Confirm-Step "Delete CloudWatch log group $LogGroup?") {
  aws logs delete-log-group --log-group-name $LogGroup --region $Region
}

# --- 8. ECR repo (force = include images) ---
if (Confirm-Step "Delete ECR repo $EcrRepo (and all images)?") {
  aws ecr delete-repository --repository-name $EcrRepo --force --region $Region --output text > $null
}

Write-Host "`n[cleanup] Done. Not deleted automatically:" -ForegroundColor Green
Write-Host "  - Entra app 'openai-basic-bot' (App ID 4b84b0fa-23b8-4d99-92b2-80bf741e04b9)" -ForegroundColor Yellow
Write-Host "  - Azure Bot 'openai-basic-bot' in RG OpenAI_weather"                                -ForegroundColor Yellow
Write-Host "Delete those with:"
Write-Host "  az ad app delete --id 4b84b0fa-23b8-4d99-92b2-80bf741e04b9"
Write-Host "  az bot delete -g OpenAI_weather -n openai-basic-bot"
